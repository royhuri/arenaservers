﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using Newtonsoft.Json;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;

namespace FortniteArenaServer
{
    // ==========================================
    // MODELS AND DATA STRUCTURES
    // ==========================================

    public class ArenaPlaylist
    {
        public string PlaylistName { get; set; }
        public string DisplayName { get; set; }
        public string Description { get; set; }
        public int MaxPlayers { get; set; }
        public string MatchType { get; set; }
        public bool Siphon { get; set; }
        public int MatsCap { get; set; }
        public bool BusFare { get; set; }
        public int RoundTimeSeconds { get; set; }
        public PlacementPoints PlacementPoints { get; set; }
        public int ElimPoints { get; set; }
        public BusFareRules BusFareRules { get; set; }
    }

    public class PlacementPoints
    {
        public int Top25 { get; set; }
        public int Top15 { get; set; }
        public int Top5 { get; set; }
        public int VictoryRoyale { get; set; }
    }

    public class BusFareRules
    {
        public int OpenLeague { get; set; }
        public int ContenderLeague { get; set; }
        public int ChampionLeague { get; set; }
    }

    public class PlayerStats
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("playerId")]
        public string PlayerID { get; set; }

        [BsonElement("hype")]
        public int Hype { get; set; }

        [BsonElement("division")]
        public int Division { get; set; }

        [BsonElement("wins")]
        public int Wins { get; set; }

        [BsonElement("totalEliminations")]
        public int TotalEliminations { get; set; }

        [BsonElement("matchesPlayed")]
        public int MatchesPlayed { get; set; }

        [BsonElement("lastPlayed")]
        public DateTime LastPlayed { get; set; }

        [BsonElement("created")]
        public DateTime Created { get; set; }
    }

    public class MatchResult
    {
        public string PlayerID { get; set; }
        public int Placement { get; set; }
        public int Eliminations { get; set; }
        public bool IsVictoryRoyale { get; set; }
        public DateTime MatchTime { get; set; }
    }

    public class LeaderboardEntry
    {
        public string PlayerID { get; set; }
        public int Hype { get; set; }
        public int Division { get; set; }
        public int Wins { get; set; }
        public int TotalEliminations { get; set; }
        public int Rank { get; set; }
    }

    // ==========================================
    // MAIN ARENA MANAGER CLASS
    // ==========================================

    public class ArenaManager
    {
        private readonly IMongoCollection<PlayerStats> _playerStats;
        private readonly IMongoDatabase _database;
        private ArenaPlaylist _currentPlaylist;

        public ArenaManager(string connectionString, string databaseName)
        {
            var client = new MongoClient(connectionString);
            _database = client.GetDatabase(databaseName);
            _playerStats = _database.GetCollection<PlayerStats>("PlayerStats");

            CreateIndexes();
        }

        private void CreateIndexes()
        {
            try
            {
                var indexKeys = Builders<PlayerStats>.IndexKeys.Ascending(p => p.PlayerID);
                var indexOptions = new CreateIndexOptions { Unique = true };
                _playerStats.Indexes.CreateOne(new CreateIndexModel<PlayerStats>(indexKeys, indexOptions));

                var leaderboardIndex = Builders<PlayerStats>.IndexKeys
                    .Descending(p => p.Hype)
                    .Descending(p => p.Wins);
                _playerStats.Indexes.CreateOne(new CreateIndexModel<PlayerStats>(leaderboardIndex));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Could not create indexes: {ex.Message}");
            }
        }

        public ArenaPlaylist LoadPlaylist(string filePath)
        {
            try
            {
                string json = File.ReadAllText(filePath);
                _currentPlaylist = JsonConvert.DeserializeObject<ArenaPlaylist>(json);
                Console.WriteLine($"✅ Loaded Arena Playlist: {_currentPlaylist.DisplayName}");
                return _currentPlaylist;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error loading playlist: {ex.Message}");
                return null;
            }
        }

        public async Task<PlayerStats> GetPlayerStatsAsync(string playerId)
        {
            var filter = Builders<PlayerStats>.Filter.Eq(p => p.PlayerID, playerId);
            var player = await _playerStats.Find(filter).FirstOrDefaultAsync();

            if (player == null)
            {
                player = new PlayerStats
                {
                    PlayerID = playerId,
                    Hype = 0,
                    Division = 1,
                    Wins = 0,
                    TotalEliminations = 0,
                    MatchesPlayed = 0,
                    LastPlayed = DateTime.UtcNow,
                    Created = DateTime.UtcNow
                };

                await _playerStats.InsertOneAsync(player);
            }

            return player;
        }

        public int CalculateHypeChange(MatchResult result, int currentDivision)
        {
            if (_currentPlaylist == null) return 0;

            int points = 0;

            // Placement points
            if (result.IsVictoryRoyale)
            {
                points += _currentPlaylist.PlacementPoints.VictoryRoyale;
            }
            else if (result.Placement <= 5)
            {
                points += _currentPlaylist.PlacementPoints.Top5;
            }
            else if (result.Placement <= 15)
            {
                points += _currentPlaylist.PlacementPoints.Top15;
            }
            else if (result.Placement <= 25)
            {
                points += _currentPlaylist.PlacementPoints.Top25;
            }

            // Elimination points
            points += result.Eliminations * _currentPlaylist.ElimPoints;

            // Bus fare
            int busFare = GetBusFare(currentDivision);
            points -= busFare;

            return points;
        }

        private int GetBusFare(int division)
        {
            if (_currentPlaylist?.BusFareRules == null) return 0;

            if (division >= 8)
                return _currentPlaylist.BusFareRules.ChampionLeague;
            else if (division >= 5)
                return _currentPlaylist.BusFareRules.ContenderLeague;
            else
                return _currentPlaylist.BusFareRules.OpenLeague;
        }

        public async Task<PlayerStats> UpdatePlayerStatsAsync(MatchResult result)
        {
            var player = await GetPlayerStatsAsync(result.PlayerID);
            int hypeChange = CalculateHypeChange(result, player.Division);

            int newHype = Math.Max(0, player.Hype + hypeChange);
            int newDivision = GetDivisionFromHype(newHype);

            var filter = Builders<PlayerStats>.Filter.Eq(p => p.PlayerID, result.PlayerID);
            var update = Builders<PlayerStats>.Update
                .Set(p => p.Hype, newHype)
                .Set(p => p.Division, newDivision)
                .Set(p => p.LastPlayed, result.MatchTime)
                .Inc(p => p.MatchesPlayed, 1)
                .Inc(p => p.TotalEliminations, result.Eliminations);

            if (result.IsVictoryRoyale)
            {
                update = update.Inc(p => p.Wins, 1);
            }

            await _playerStats.UpdateOneAsync(filter, update);

            Console.WriteLine($"🎮 {result.PlayerID}: #{result.Placement} with {result.Eliminations} elims → Hype: {player.Hype} → {newHype} (Change: {hypeChange:+#;-#;0}), Division: {GetDivisionName(newDivision)}");

            return await GetPlayerStatsAsync(result.PlayerID);
        }

        private int GetDivisionFromHype(int hype)
        {
            if (hype < 300) return 1;      // Open League I
            if (hype < 600) return 2;      // Open League II  
            if (hype < 1000) return 3;     // Open League III
            if (hype < 1500) return 4;     // Open League IV
            if (hype < 2500) return 5;     // Contender League I
            if (hype < 4000) return 6;     // Contender League II
            if (hype < 6000) return 7;     // Contender League III
            if (hype < 8000) return 8;     // Champion League I
            if (hype < 10000) return 9;    // Champion League II
            return 10;                     // Champion League III
        }

        public string GetDivisionName(int division)
        {
            return division switch
            {
                1 => "Open League I",
                2 => "Open League II",
                3 => "Open League III",
                4 => "Open League IV",
                5 => "Contender League I",
                6 => "Contender League II",
                7 => "Contender League III",
                8 => "Champion League I",
                9 => "Champion League II",
                10 => "Champion League III",
                _ => "Unknown Division"
            };
        }

        public async Task<List<LeaderboardEntry>> GetLeaderboardAsync(int limit = 100)
        {
            var sort = Builders<PlayerStats>.Sort
                .Descending(p => p.Hype)
                .Descending(p => p.Wins);

            var players = await _playerStats.Find(FilterDefinition<PlayerStats>.Empty)
                .Sort(sort)
                .Limit(limit)
                .ToListAsync();

            var leaderboard = players.Select((player, index) => new LeaderboardEntry
            {
                PlayerID = player.PlayerID,
                Hype = player.Hype,
                Division = player.Division,
                Wins = player.Wins,
                TotalEliminations = player.TotalEliminations,
                Rank = index + 1
            }).ToList();

            return leaderboard;
        }

        public async Task<List<PlayerStats>> GetPlayersInDivisionAsync(int division, int limit = 100)
        {
            var filter = Builders<PlayerStats>.Filter.Eq(p => p.Division, division);
            var sort = Builders<PlayerStats>.Sort.Descending(p => p.Hype);

            return await _playerStats.Find(filter)
                .Sort(sort)
                .Limit(limit)
                .ToListAsync();
        }

        public async Task<long> GetTotalPlayersAsync()
        {
            return await _playerStats.CountDocumentsAsync(FilterDefinition<PlayerStats>.Empty);
        }

        public async Task ResetPlayerStatsAsync(string playerId)
        {
            var filter = Builders<PlayerStats>.Filter.Eq(p => p.PlayerID, playerId);
            var update = Builders<PlayerStats>.Update
                .Set(p => p.Hype, 0)
                .Set(p => p.Division, 1)
                .Set(p => p.Wins, 0)
                .Set(p => p.TotalEliminations, 0)
                .Set(p => p.MatchesPlayed, 0);

            await _playerStats.UpdateOneAsync(filter, update);
            Console.WriteLine($"🔄 Reset stats for player: {playerId}");
        }
    }

    // ==========================================
    // HTTP API FOR EXTERNAL INTEGRATION
    // ==========================================

    public class ArenaHttpServer
    {
        private HttpListener _listener;
        private ArenaManager _arenaManager;
        private bool _isRunning;

        public ArenaHttpServer(ArenaManager arenaManager, string prefix = "http://localhost:8080/")
        {
            _arenaManager = arenaManager;
            _listener = new HttpListener();
            _listener.Prefixes.Add(prefix);
        }

        public async Task StartAsync()
        {
            _listener.Start();
            _isRunning = true;
            Console.WriteLine($"🌐 Arena HTTP API started on {_listener.Prefixes.First()}");
            Console.WriteLine("API Endpoints:");
            Console.WriteLine("  POST /api/match-result - Submit match results");
            Console.WriteLine("  GET /api/leaderboard - Get leaderboard");
            Console.WriteLine("  GET /api/player/{playerId} - Get player stats");
            Console.WriteLine();

            while (_isRunning)
            {
                try
                {
                    var context = await _listener.GetContextAsync();
                    _ = Task.Run(() => HandleRequestAsync(context));
                }
                catch (Exception ex)
                {
                    if (_isRunning)
                        Console.WriteLine($"❌ HTTP Server error: {ex.Message}");
                }
            }
        }

        private async Task HandleRequestAsync(HttpListenerContext context)
        {
            var request = context.Request;
            var response = context.Response;

            try
            {
                string responseString = "";

                if (request.HttpMethod == "POST" && request.Url.AbsolutePath == "/api/match-result")
                {
                    responseString = await HandleMatchResult(request);
                }
                else if (request.HttpMethod == "GET" && request.Url.AbsolutePath == "/api/leaderboard")
                {
                    responseString = await HandleLeaderboard(request);
                }
                else if (request.HttpMethod == "GET" && request.Url.AbsolutePath.StartsWith("/api/player/"))
                {
                    var playerId = request.Url.AbsolutePath.Replace("/api/player/", "");
                    responseString = await HandlePlayerStats(playerId);
                }
                else
                {
                    response.StatusCode = 404;
                    responseString = JsonConvert.SerializeObject(new { error = "Endpoint not found" });
                }

                byte[] buffer = Encoding.UTF8.GetBytes(responseString);
                response.ContentType = "application/json";
                response.ContentLength64 = buffer.Length;
                await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
            }
            catch (Exception ex)
            {
                response.StatusCode = 500;
                byte[] errorBuffer = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(new { error = ex.Message }));
                await response.OutputStream.WriteAsync(errorBuffer, 0, errorBuffer.Length);
            }
            finally
            {
                response.Close();
            }
        }

        private async Task<string> HandleMatchResult(HttpListenerRequest request)
        {
            using var reader = new StreamReader(request.InputStream);
            var json = await reader.ReadToEndAsync();
            var result = JsonConvert.DeserializeObject<MatchResult>(json);

            var updatedStats = await _arenaManager.UpdatePlayerStatsAsync(result);

            return JsonConvert.SerializeObject(new
            {
                success = true,
                playerId = updatedStats.PlayerID,
                hype = updatedStats.Hype,
                division = updatedStats.Division,
                divisionName = _arenaManager.GetDivisionName(updatedStats.Division),
                wins = updatedStats.Wins,
                totalEliminations = updatedStats.TotalEliminations
            });
        }

        private async Task<string> HandleLeaderboard(HttpListenerRequest request)
        {
            var limit = int.TryParse(request.QueryString["limit"], out var l) ? l : 100;
            var leaderboard = await _arenaManager.GetLeaderboardAsync(limit);

            return JsonConvert.SerializeObject(new { success = true, leaderboard });
        }

        private async Task<string> HandlePlayerStats(string playerId)
        {
            var stats = await _arenaManager.GetPlayerStatsAsync(playerId);

            return JsonConvert.SerializeObject(new
            {
                success = true,
                player = new
                {
                    playerId = stats.PlayerID,
                    hype = stats.Hype,
                    division = stats.Division,
                    divisionName = _arenaManager.GetDivisionName(stats.Division),
                    wins = stats.Wins,
                    totalEliminations = stats.TotalEliminations,
                    matchesPlayed = stats.MatchesPlayed,
                    lastPlayed = stats.LastPlayed
                }
            });
        }

        public void Stop()
        {
            _isRunning = false;
            _listener?.Stop();
        }
    }

    // ==========================================
    // MAIN PROGRAM ENTRY POINT
    // ==========================================

    class Program
    {
        private static ArenaManager arenaManager;
        private static ArenaHttpServer httpServer;

        static async Task Main(string[] args)
        {
            Console.WriteLine("🎯 Fortnite Arena Backend v13.40");
            Console.WriteLine("==================================");

            try
            {
                // Initialize Arena Manager
                Console.WriteLine("🔌 Connecting to MongoDB...");
                arenaManager = new ArenaManager("mongodb://localhost:27017", "FortniteArenaDB");
                Console.WriteLine("✅ Connected to MongoDB");

                // Load Arena playlist
                Console.WriteLine("📄 Loading Arena playlist...");
                var playlist = arenaManager.LoadPlaylist("ArenaPlaylist.json");
                if (playlist == null)
                {
                    Console.WriteLine("❌ Failed to load ArenaPlaylist.json");
                    Console.WriteLine("Make sure the file exists in the same folder");
                    Console.WriteLine("Press any key to exit...");
                    Console.ReadKey();
                    return;
                }

                DisplayPlaylistInfo(playlist);

                // Start HTTP API server
                httpServer = new ArenaHttpServer(arenaManager);
                _ = Task.Run(() => httpServer.StartAsync());

                // Start interactive console
                await StartInteractiveConsole();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Fatal error: {ex.Message}");
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }
        }

        static void DisplayPlaylistInfo(ArenaPlaylist playlist)
        {
            Console.WriteLine($"✅ Arena Mode: {playlist.DisplayName}");
            Console.WriteLine($"   Max Players: {playlist.MaxPlayers}");
            Console.WriteLine($"   Siphon: {playlist.Siphon}");
            Console.WriteLine($"   Mats Cap: {playlist.MatsCap}");
            Console.WriteLine($"   Victory Royale: +{playlist.PlacementPoints.VictoryRoyale} Hype");
            Console.WriteLine($"   Top 5: +{playlist.PlacementPoints.Top5} Hype");
            Console.WriteLine($"   Eliminations: +{playlist.ElimPoints} Hype each");
            Console.WriteLine();
        }

        static async Task StartInteractiveConsole()
        {
            Console.WriteLine("🚀 Arena Backend is running!");
            Console.WriteLine("\nCommands:");
            Console.WriteLine("  'q' = Quit");
            Console.WriteLine("  'l' = Show Leaderboard");
            Console.WriteLine("  's' = Show Statistics");
            Console.WriteLine("  't' = Test Match");
            Console.WriteLine("  'r' = Reset Player");
            Console.WriteLine("  'h' = Help");
            Console.WriteLine();

            while (true)
            {
                Console.Write("Arena> ");
                var input = Console.ReadLine()?.ToLower().Trim();

                switch (input)
                {
                    case "q":
                    case "quit":
                        Console.WriteLine("👋 Shutting down Arena backend...");
                        httpServer?.Stop();
                        return;

                    case "l":
                    case "leaderboard":
                        await ShowLeaderboard();
                        break;

                    case "s":
                    case "stats":
                        await ShowStats();
                        break;

                    case "t":
                    case "test":
                        await RunTestMatch();
                        break;

                    case "r":
                    case "reset":
                        await ResetPlayer();
                        break;

                    case "h":
                    case "help":
                        ShowHelp();
                        break;

                    case "":
                        break;

                    default:
                        Console.WriteLine("Unknown command. Type 'h' for help.");
                        break;
                }
            }
        }

        static async Task ShowLeaderboard()
        {
            try
            {
                Console.WriteLine("\n🏆 Arena Leaderboard (Top 20)");
                Console.WriteLine("Rank | Player ID       | Hype  | Division            | W | Elims");
                Console.WriteLine("-----|-----------------|-------|---------------------|---|------");

                var leaderboard = await arenaManager.GetLeaderboardAsync(20);

                if (leaderboard.Count == 0)
                {
                    Console.WriteLine("No players found. Run some test matches first!");
                }
                else
                {
                    foreach (var entry in leaderboard)
                    {
                        Console.WriteLine($"{entry.Rank,4} | {entry.PlayerID,-15} | {entry.Hype,5} | {arenaManager.GetDivisionName(entry.Division),-19} | {entry.Wins,1} | {entry.TotalEliminations,4}");
                    }
                }

                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
            }
        }

        static async Task ShowStats()
        {
            try
            {
                var totalPlayers = await arenaManager.GetTotalPlayersAsync();
                Console.WriteLine($"\n📊 Arena Statistics");
                Console.WriteLine($"Total Players: {totalPlayers}");

                if (totalPlayers > 0)
                {
                    Console.WriteLine("\nDivision Distribution:");
                    for (int div = 1; div <= 10; div++)
                    {
                        var playersInDiv = await arenaManager.GetPlayersInDivisionAsync(div, 1000);
                        if (playersInDiv.Count > 0)
                        {
                            Console.WriteLine($"  {arenaManager.GetDivisionName(div)}: {playersInDiv.Count} players");
                        }
                    }
                }

                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
            }
        }

        static async Task RunTestMatch()
        {
            try
            {
                Console.Write("Enter player ID (or press Enter for random): ");
                var playerId = Console.ReadLine()?.Trim();
                if (string.IsNullOrEmpty(playerId))
                {
                    var random = new Random();
                    playerId = $"TestPlayer{random.Next(100, 999)}";
                }

                Console.Write("Enter placement (1-100, or press Enter for random): ");
                var placementInput = Console.ReadLine()?.Trim();
                int placement;
                if (string.IsNullOrEmpty(placementInput))
                {
                    placement = new Random().Next(1, 101);
                }
                else if (!int.TryParse(placementInput, out placement) || placement < 1 || placement > 100)
                {
                    Console.WriteLine("Invalid placement. Using random value.");
                    placement = new Random().Next(1, 101);
                }

                Console.Write("Enter eliminations (0-20, or press Enter for random): ");
                var elimsInput = Console.ReadLine()?.Trim();
                int eliminations;
                if (string.IsNullOrEmpty(elimsInput))
                {
                    eliminations = new Random().Next(0, 16);
                }
                else if (!int.TryParse(elimsInput, out eliminations) || eliminations < 0 || eliminations > 20)
                {
                    Console.WriteLine("Invalid eliminations. Using random value.");
                    eliminations = new Random().Next(0, 16);
                }

                var result = new MatchResult
                {
                    PlayerID = playerId,
                    Placement = placement,
                    Eliminations = eliminations,
                    IsVictoryRoyale = placement == 1,
                    MatchTime = DateTime.UtcNow
                };

                Console.WriteLine($"\n🎮 Processing match for {playerId}...");
                await arenaManager.UpdatePlayerStatsAsync(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
            }
        }

        static async Task ResetPlayer()
        {
            try
            {
                Console.Write("Enter player ID to reset: ");
                var playerId = Console.ReadLine()?.Trim();

                if (string.IsNullOrEmpty(playerId))
                {
                    Console.WriteLine("Player ID cannot be empty.");
                    return;
                }

                await arenaManager.ResetPlayerStatsAsync(playerId);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
            }
        }

        static void ShowHelp()
        {
            Console.WriteLine("\n📖 Available Commands:");
            Console.WriteLine("  'q' or 'quit'       - Exit the program");
            Console.WriteLine("  'l' or 'leaderboard' - Show top 20 players");
            Console.WriteLine("  's' or 'stats'      - Show server statistics");
            Console.WriteLine("  't' or 'test'       - Run a test match");
            Console.WriteLine("  'r' or 'reset'      - Reset a player's stats");
            Console.WriteLine("  'h' or 'help'       - Show this help");
            Console.WriteLine("\n🌐 HTTP API:");
            Console.WriteLine("  POST http://localhost:8080/api/match-result");
            Console.WriteLine("  GET  http://localhost:8080/api/leaderboard");
            Console.WriteLine("  GET  http://localhost:8080/api/player/{playerId}");
            Console.WriteLine();
        }

        // Public method for external integration
        public static async Task<PlayerStats> ProcessMatchResult(string playerId, int placement, int eliminations)
        {
            var result = new MatchResult
            {
                PlayerID = playerId,
                Placement = placement,
                Eliminations = eliminations,
                IsVictoryRoyale = placement == 1,
                MatchTime = DateTime.UtcNow
            };

            return await arenaManager.UpdatePlayerStatsAsync(result);
        }
    }
}